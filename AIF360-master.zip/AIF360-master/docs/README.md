## Docs
To generate the documentation, run `make` from the `docs/` directory.

## Style
This project uses Google-style docstrings. See:
http://www.sphinx-doc.org/en/1.5/ext/example_google.html
for more details.
