.. aif360-bias-toolbox documentation master file, created by
   sphinx-quickstart on Fri Jun  8 14:05:59 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to AI Fairness 360's documentation!
===========================================

.. toctree::
   :maxdepth: 3
   :caption: Modules

   modules/algorithms
   modules/datasets
   modules/explainers
   modules/metrics


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
