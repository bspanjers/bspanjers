:mod:`aif360.explainers`
========================

.. automodule:: aif360.explainers

Metric Text Explainer
---------------------

.. autoclass:: MetricTextExplainer
    :members:

Metric JSON Explainer
---------------------

.. autoclass:: MetricJSONExplainer
    :members:
